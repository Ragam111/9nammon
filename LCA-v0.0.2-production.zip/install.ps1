﻿# install.ps1 — ตัวติดตั้ง Local Code Assistant บน Windows 10/11 (AMD64)
# รันด้วย: powershell -ExecutionPolicy Bypass -File install.ps1
# (หรือดับเบิลคลิก install.bat ซึ่งเรียกไฟล์นี้ให้อัตโนมัติ)

$ErrorActionPreference = "Stop"

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$CurrentVersion = "0.0.2"

Write-Host "=== Local Code Assistant — ตัวติดตั้ง (Windows) ===" -ForegroundColor Cyan

# ---------- ขั้นตอน 0: เลือกไดรฟ์ติดตั้ง (ถามเสมอ ไม่ fallback เงียบๆ) ----------
# ค่าเริ่มต้นคือ %LOCALAPPDATA% (มักอยู่บน C:) แต่ถ้าผู้ใช้อยากติดตั้งบนไดรฟ์อื่น
# เช่น D: (พื้นที่ C: จำกัด) ให้เลือกได้ตรงนี้ — เช็คว่าไดรฟ์ที่เลือกมีอยู่จริงก่อนเสมอ
Write-Host ""
Write-Host "จะติดตั้งที่ไดรฟ์ไหน?"
Write-Host "  [1] ค่าเริ่มต้น ($env:LOCALAPPDATA)"
Write-Host "  [2] ไดรฟ์ D: (D:\LocalCodeAssistant)"
Write-Host "  [3] ระบุ path เอง"
$driveChoice = Read-Host "เลือก (1/2/3, กด Enter = 1)"

switch ($driveChoice) {
    "2" {
        if (-not (Test-Path "D:\")) {
            Write-Host "[error] ไม่พบไดรฟ์ D: บนเครื่องนี้ — เลือกตัวเลือกอื่นแทน" -ForegroundColor Red
            exit 1
        }
        $freeSpaceGB = [math]::Round((Get-PSDrive D).Free / 1GB, 1)
        if ($freeSpaceGB -lt 2) {
            Write-Host "[error] ไดรฟ์ D: เหลือพื้นที่แค่ ${freeSpaceGB}GB (ต้องการอย่างน้อย 2GB สำหรับตัวโปรแกรม" -ForegroundColor Red
            Write-Host "        ไม่รวมโมเดล Ollama ที่แยก pull เองซึ่งอาจกินอีกหลาย GB) — เลือกตัวเลือกอื่นแทน" -ForegroundColor Red
            exit 1
        }
        $InstallDir = "D:\LocalCodeAssistant"
        Write-Host "[ok] ติดตั้งที่ D:\LocalCodeAssistant (เหลือพื้นที่ ${freeSpaceGB}GB)"
    }
    "3" {
        $customPath = Read-Host "พิมพ์ path เต็มที่ต้องการติดตั้ง (เช่น E:\Tools\LCA)"
        $customDrive = (Split-Path -Qualifier $customPath -ErrorAction SilentlyContinue)
        if (-not $customDrive -or -not (Test-Path "$customDrive\")) {
            Write-Host "[error] ไม่พบไดรฟ์ที่ระบุ ($customPath) — ยกเลิกการติดตั้ง" -ForegroundColor Red
            exit 1
        }
        $InstallDir = $customPath
        Write-Host "[ok] ติดตั้งที่ $InstallDir"
    }
    default {
        $InstallDir = Join-Path $env:LOCALAPPDATA "LocalCodeAssistant"
        Write-Host "[ok] ติดตั้งที่ค่าเริ่มต้น: $InstallDir"
    }
}

$VersionFile = Join-Path $InstallDir "version.txt"

# ---------- ขั้นตอน 1: ตรวจสอบ Python ----------
function Test-Command($name) {
    try { Get-Command $name -ErrorAction Stop | Out-Null; return $true }
    catch { return $false }
}

$pythonCmd = $null
foreach ($candidate in @("python", "python3")) {
    if (Test-Command $candidate) { $pythonCmd = $candidate; break }
}
if (-not $pythonCmd) {
    Write-Host "[error] ไม่พบ Python ในเครื่อง — ติดตั้งก่อนที่ https://www.python.org/downloads/" -ForegroundColor Red
    Write-Host "        (เลือก 'Add python.exe to PATH' ตอนติดตั้งด้วย)" -ForegroundColor Yellow
    exit 1
}
Write-Host "[ok] พบ Python: $pythonCmd"

# ---------- ขั้นตอน 2: ตรวจสอบ Ollama ----------
$hasOllama = Test-Command "ollama"
if (-not $hasOllama) {
    Write-Host "[warn] ไม่พบ Ollama ในเครื่อง — ดาวน์โหลดที่ https://ollama.com/download/windows" -ForegroundColor Yellow
    Write-Host "        ติดตั้งเสร็จแล้วรัน install.ps1 นี้ใหม่อีกครั้ง (หรือรันต่อได้ แต่ pull โมเดลเองทีหลัง)"
} else {
    Write-Host "[ok] พบ Ollama"
}

# ---------- ขั้นตอน 3: ตรวจ RAM แล้วเลือกโมเดลที่แนะนำ ----------
$totalRamBytes = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory
$totalRamGB = [math]::Round($totalRamBytes / 1GB, 1)

function Get-RecommendedModel($ramGB) {
    if ($ramGB -lt 8)  { return @{ Model = "qwen2.5-coder:0.5b"; Tier = "ต่ำกว่า 8GB (ใช้โมเดลเล็กสุด อาจยังหน่วง)" } }
    if ($ramGB -lt 16) { return @{ Model = "qwen2.5-coder:1.5b"; Tier = "8GB" } }
    if ($ramGB -lt 32) { return @{ Model = "qwen2.5-coder:7b";   Tier = "16GB" } }
    if ($ramGB -lt 64) { return @{ Model = "qwen2.5-coder:14b";  Tier = "32GB" } }
    return @{ Model = "qwen2.5-coder:32b"; Tier = "64GB ขึ้นไป" }
}

$rec = Get-RecommendedModel $totalRamGB
Write-Host ""
Write-Host "[ram] เครื่องนี้มี RAM ประมาณ $totalRamGB GB (ระดับ: $($rec.Tier))"
Write-Host "[ram] โมเดลที่แนะนำ: $($rec.Model)" -ForegroundColor Green

$modelChoice = Read-Host "กด Enter เพื่อใช้โมเดลที่แนะนำ หรือพิมพ์ชื่อโมเดล Ollama อื่นที่ต้องการ"
if ([string]::IsNullOrWhiteSpace($modelChoice)) { $modelChoice = $rec.Model }

# ---------- ขั้นตอน 4: คัดลอกไฟล์ไปที่โฟลเดอร์ติดตั้ง ----------
if (Test-Path $InstallDir) {
    Write-Host "[info] พบการติดตั้งเดิมที่ $InstallDir — ไฟล์ผู้ใช้ (todos.json, CHANGELOG_local.md) จะไม่ถูกลบ"
} else {
    New-Item -ItemType Directory -Path $InstallDir | Out-Null
}

Copy-Item -Path (Join-Path $ScriptRoot "local_coder.py") -Destination $InstallDir -Force
Copy-Item -Path (Join-Path $ScriptRoot "server.py") -Destination $InstallDir -Force
$AppDestDir = Join-Path $InstallDir "app"
if (-not (Test-Path $AppDestDir)) { New-Item -ItemType Directory -Path $AppDestDir | Out-Null }
Copy-Item -Path (Join-Path $ScriptRoot "app\*") -Destination $AppDestDir -Recurse -Force

# folder_trust.py / context_manager.py อยู่ที่ root ของแพ็กเกจ (ไม่ใช่ใน app\)
# แต่ local_coder.py import ผ่าน sys.path ที่ชี้ไปโฟลเดอร์ app\ ตอนรัน
# ต้องคัดลอกมาไว้ที่นี่ด้วยเสมอ ไม่งั้นจะเจอ ModuleNotFoundError ตอนเปิดโปรแกรม
# (เคยเกิดจริง — ดู SKILL.md Troubleshooting และ fix_missing_modules.ps1)
Copy-Item -Path (Join-Path $ScriptRoot "folder_trust.py") -Destination $AppDestDir -Force
Copy-Item -Path (Join-Path $ScriptRoot "context_manager.py") -Destination $AppDestDir -Force

Set-Content -Path $VersionFile -Value $CurrentVersion -Encoding UTF8
Set-Content -Path (Join-Path $InstallDir "default_model.txt") -Value $modelChoice -Encoding UTF8

Write-Host "[ok] ติดตั้งไฟล์ไปที่ $InstallDir แล้ว"

# ---------- ขั้นตอน 5: สร้าง launcher (lca.bat) ----------
$LauncherPath = Join-Path $InstallDir "lca.bat"
$LauncherContent = @"
@echo off
REM lca.bat — เรียกใช้ Local Code Assistant จากที่ไหนก็ได้ใน terminal
$pythonCmd "$InstallDir\local_coder.py" --model $modelChoice %*
"@
Set-Content -Path $LauncherPath -Value $LauncherContent -Encoding ASCII

$WebLauncherPath = Join-Path $InstallDir "lca-web.bat"
$WebLauncherContent = @"
@echo off
REM lca-web.bat — เปิดหน้าเว็บ Chat UI (ต้องระบุโฟลเดอร์โปรเจกต์เป็น argument แรก)
$pythonCmd "$InstallDir\server.py" %*
"@
Set-Content -Path $WebLauncherPath -Value $WebLauncherContent -Encoding ASCII

Write-Host "[ok] สร้าง launcher แล้ว: lca.bat (CLI), lca-web.bat (หน้าเว็บ)"

# ---------- ขั้นตอน 6: เพิ่ม InstallDir เข้า PATH ผู้ใช้ (ถ้ายังไม่มี) ----------
$currentPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($currentPath -notlike "*$InstallDir*") {
    [Environment]::SetEnvironmentVariable("Path", "$currentPath;$InstallDir", "User")
    Write-Host "[ok] เพิ่ม $InstallDir เข้า PATH แล้ว — ต้องเปิด terminal ใหม่ถึงจะเรียก lca ได้ทุกที่"
} else {
    Write-Host "[ok] $InstallDir อยู่ใน PATH อยู่แล้ว"
}

# ---------- สรุป ----------
Write-Host ""
Write-Host "=== ติดตั้งเสร็จสมบูรณ์ ===" -ForegroundColor Cyan
Write-Host "1. เปิด terminal (CMD/PowerShell) ใหม่"
if ($hasOllama) {
    Write-Host "2. ดึงโมเดล: ollama pull $modelChoice"
} else {
    Write-Host "2. ติดตั้ง Ollama ก่อน แล้วรัน: ollama pull $modelChoice"
}
Write-Host "3. ใช้งาน: lca C:\path\to\your\project"
Write-Host "   หรือเปิดหน้าเว็บ: lca-web C:\path\to\your\project"
